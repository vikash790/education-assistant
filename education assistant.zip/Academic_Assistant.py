import streamlit as st
import pandas as pd

st.write("Hello Dear, Welcome to the best and your only education assistance app.")
st.title("Your Academic Helper")

st.markdown("Give us your basic details")

name=st.text_input('What Is Your Name')

College = st.radio('Pick Your Dream', ['IIT', 'NIT'])


if College == 'IIT':
    Category = st.radio('Category', ['OPEN', 'EWS', 'OBC-NCL', 'ST', 'SC'])
    Program = st.selectbox('Pick a program', [
        " Bachelor of Technology",
        " Bachelor and Master of Technology ",
        " Bachelor of Science",
        " Bachelor of Architecture",
        " Bachelor of Science and Master of Science ",
        " Integrated Master of Technology"

    ])
    Branch = st.selectbox("Interests/Preferences: ", ["Civil Engineering ", "Civil Engineering and M. Tech. in Structural Engineering ", "Civil Engineering and M.Tech in Transportation Engineering ", "Civil Engineering and M.Tech. in Environmental Engineering ", "Computer Science and Engineering ", "Electrical Engineering and M.Tech Power Electronics and Drives ", "Electrical Engineering ", "Electronics and Communication Engineering ", "Mechanical Engineering ", "Mechanical Engineering and M. Tech. in Mechanical System Design ", "Mechanical Engineering and M. Tech. in Thermal Science & Engineering ", "Mechanical Engineering with M.Tech. in Manufacturing Engineering ", "Metallurgical and Materials Engineering ", "Aerospace Engineering ", "BS in Mathematics ", "Chemical Engineering ", "Chemistry ", "Economics ", "Energy Engineering ", "Engineering Physics ", "Environmental Science and Engineering ", "Mechanical Engineering and M.Tech. in Computer Integrated Manufacturing ", "Metallurgical Engineering and Materials Science ", "Bio Engineering ", "Data Science and Engineering ", "Biotechnology and Biochemical Engineering ", "Engineering and Computational Mechanics ", "Materials Engineering ", "Mathematics and Computing ", "Production and Industrial Engineering ", "Textile Technology ", "Agricultural and Food Engineering ", "Agricultural and Food Engineering with M.Tech. in any of the listed specializations ", "Applied Geology ", "Architecture ", "Civil Engineering with any of the listed specialization ", "Electrical Engineering with M.Tech. in any of the listed specializations ", "Electronics and Electrical Communication Engineering ", "Electronics and Electrical Communication Engineering with M.Tech. in any of the listed specializations ", "Exploration Geophysics ", "Industrial and Systems Engineering ", "Industrial and Systems Engineering with M.Tech. in Industrial and Systems Engineering and Management ", "Instrumentation Engineering ",
                          "Manufacturing Science and Engineering ", "Manufacturing Science and Engineering with M.Tech. in Industrial and Systems Engineering and Management ", "Mechanical Engineering with M.Tech. in any of the listed specializations ", "Mining Engineering ", "Mining Safety Engineering ", "Ocean Engineering and Naval Architecture ", "Physics ", "Artificial Intelligence ", "Biomedical Engineering ", "Biotechnology and Bioinformatics ", "Computational Engineering ", "Engineering Science ", "Industrial Chemistry ", "Materials Science and Metallurgical Engineering ", "Artificial Intelligence and Data Science ", "Chemistry with Specialization ", "Civil and Infrastructure Engineering ", "Physics with Specialization ", "Biological Sciences and Bioengineering ", "Earth Sciences ", "Materials Science and Engineering ", "Mathematics and Scientific Computing ", "Statistics and Data Science ", "Biological Engineering ", "Biological Sciences ", "Engineering Design ", "Naval Architecture and Ocean Engineering ", "Electrical and Electronics Engineering ", "Biosciences and Bioengineering ", "Chemical Sciences ", "Data Science and Artificial Intelligence ", "Geological Technology ", "Geophysical Technology ", "Mathematics & Computing ", "Applied Geophysics ", "Environmental Engineering ", "Mineral and Metallurgical Engineering ", "Mining Machinery Engineering ", "Petroleum Engineering ", "Biochemical Engineering with M.Tech. in Biochemical Engineering and Biotechnology ", "Bioengineering with M.Tech in Biomedical Technology ", "Ceramic Engineering ", "Electrical Engineering with M.Tech. in Power Electronics ", "Electronics Engineering ", "Materials Science and Technology ", "Metallurgical Engineering ", "Pharmaceutical Engineering & Technology ", "Chemical Science and Technology ", "Electronics and Electrical Engineering ", "Mechatronics Engineering ", "Chemical and Biochemical Engineering ", "Interdisciplinary Sciences "])

    Rank = st.number_input('JEE Advance Rank', 1)

    data = pd.read_excel('Copy of IITJEE(1).xlsx', usecols=[
        'NIRF','Institute', 'Academic Program Name', 'Course', 'Seat Type', 'Opening Rank', 'Closing Rank'])


# Display the filtered data

    df = pd.DataFrame(data)

    df['Opening Rank'] = pd.to_numeric(df['Opening Rank'], errors='coerce')
    df['Closing Rank'] = pd.to_numeric(df['Closing Rank'], errors='coerce')

    df = df[(df['Opening Rank'] >= Rank) & (df['Closing Rank'] <= Rank + 10000) &
            (df['Seat Type'] == Category) & (df['Course'] == Program) & (df['Academic Program Name'] == Branch)]

    df.sort_values(by='Opening Rank', inplace=True)
    df = df.reset_index(drop=True)
    st.dataframe(df)


else:
    Category = st.radio('Category', ['OPEN', 'EWS', 'OBC-NCL', 'ST', 'SC'])
    CState = st.select_slider('College State', ['Home', 'Other', 'Any'])
    if CState == "Home":
        CState = "HS"
    elif CState == "Other":
        CState = "OS"
    else:
        CState = ''
    Program = st.selectbox('Pick a program', [
        " Bachelor of Technology",
        " Bachelor of Architecture",
        " Bachelor and Master of Technology ",
        " Bachelor of Planning",
        " Bachelor of Science and Master of Science ",
        " Integrated Master of Science"
    ])
    Branch = st.selectbox("Interests/Preferences: ", ["Electronics and Communication Engineering ", "Bio Technology ", "Chemical Engineering ", "Civil Engineering ", "Computer Science and Engineering ", "Electrical Engineering ", "Industrial and Production Engineering ", "Information Technology ", "Instrumentation and Control Engineering ", "Mechanical Engineering ", "Textile Technology ", "Architecture ", "Metallurgical and Materials Engineering ", "Materials Science and Metallurgical Engineering ", "Mathematics and Data Science ", "Planning ", "Production and Industrial Engineering ", "Biotechnology and Biochemical Engineering ", "Chemistry ", "Computational Mathematics ", "Electronics and Instrumentation Engineering ", "Engineering Physics ", "Mathematics &amp; Computing ", "Physics ", "Production Engineering ", "Electrical and Electronics Engineering ", "Materials Science and Engineering ", "Biotechnology ", "Mathematics and Computing ", "Artificial Intelligence ", "Computational and Data Science ",
                          "Mining Engineering ", "Civil Engineering with Specialization in Construction Technology and Management ", "Computer Science and Engineering with Specialization in Cyber Security ", "Computer Science and Engineering with Specialization in Data Science ", "Electrical Engineering with Specialization In Power System Engineering ", "Electronics and Communication Engineering with Specialization in Microelectronics and VLSI System Design ", "Material Science and Engineering ", "Mathematics and Computing Technology ", "Mechanical Engineering with Specialization in Manufacturing and Industrial Engineering ", "Bio Medical Engineering ", "Engineering and Computational Mechanics ", "Computer Engineering ", "Ceramic Engineering ", "Ceramic Engineering and M.Tech Industrial Ceramic ", "Food Process Engineering ", "Industrial Design ", "Life Science ", "Mathematics ", "Aerospace Engineering ", "Electronics and Telecommunication Engineering ", "Metallurgy and Materials Engineering "])

    Rank = st.number_input('JEE Mains Rank', 1)

    data = pd.read_excel('Copy of JEE(1).xlsx', usecols=[
        'NIRF','Institute', 'Academic Program Name', 'Course', 'Quota', 'Seat Type', 'Opening Rank', 'Closing Rank'])
    df = pd.DataFrame(data)
    if CState == '':
        df = df.query('`Opening Rank` >= {} and `Closing Rank` <= {} and `Seat Type` == "{}" and `Course` == "{}" and `Academic Program Name` == "{}"'.format(
            Rank, Rank+10000, Category, Program, Branch))
    else:
        df = df.query('`Opening Rank` >= {} and `Closing Rank` <= {} and Quota == "{}" and `Seat Type` == "{}" and `Course` == "{}" and `Academic Program Name` == "{}"'.format(
            Rank, Rank+10000, CState, Category, Program, Branch))
    df.sort_values(by='Opening Rank', inplace=True)
    # table = st.table(df)
    df = df.reset_index(drop=True)
    st.dataframe(df)

bid = pd.read_excel('Book1.xlsx', usecols=['Academic Program Name', 'Books', 'Book Author', 'Purchasing Link', 'Courses', 'Platform', 'Course Link'])

# Filter the DataFrame based on the selected branch
filtered_data = bid[bid['Academic Program Name'] == Branch]
book_df = filtered_data[['Books', 'Book Author', 'Purchasing Link']]

# Create a DataFrame for course-related information
course_df = filtered_data[['Courses', 'Platform', 'Course Link']]
book_df = book_df.reset_index(drop=True)
course_df = course_df.reset_index(drop=True)
st.markdown("Hi, " + name + "! Based On Your Interest , We Have Some Book Recommendation")
st.dataframe(book_df)

st.markdown("Hi Again 😎, " + name + " ! Based On Your Interest , We Have Some Online Course Recommendation")

st.dataframe(course_df)


# Display the filtered data
# st.dataframe(filtered_data)


